// Player prefab constructor function
function Snowfall(game, key, frame, scale, rotation) {
	// call to Phaser.Sprite 
	// new Sprite(game, x, y, key, frame)
	Phaser.Sprite.call(this, game, game.rnd.integerInRange(64,game.width-64), game.rnd.integerInRange(64,game.height-61), key, frame);

	// add custom properties
	this.anchor.set(0.5);
	this.scale.x = scale;
	this.scale.y = scale;
	this.rotation = rotation;
    

	// put some physics on it
	game.physics.enable(this);
    this.body.gravity.y = 100;
    this.body.maxVelocity.y = 100;
	this.body.collideWorldBounds = true;
	this.body.angularVelocity = game.rnd.integerInRange(0,320);
    this.body.velocity.x = game.rnd.integerInRange(0,100);
    //Snowfall reversal effect
    this.reverseKey = game.input.keyboard.addKey(Phaser.Keyboard.R);
}
// explicitly define prefab's prototype (Phaser.Sprite) and constructor (Player)
Snowfall.prototype = Object.create(Phaser.Sprite.prototype);
Snowfall.prototype.constructor = Snowfall;

// override Phaser.Sprite update (to spin the object)
Snowfall.prototype.update = function() {
    //Will give the player ability to reverse snowfall by accessing user input
    if(this.reverseKey.justPressed()){
        this.body.velocity.x *= -1;
    }
	if(game.input.keyboard.isDown(Phaser.Keyboard.UP)) {
		this.body.angularVelocity += 5;
	}
	if(game.input.keyboard.isDown(Phaser.Keyboard.DOWN)) {
		this.body.angularVelocity -= 5;
	}
}